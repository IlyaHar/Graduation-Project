<?php $__env->startSection('title'); ?> Авторизация <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex flex-column align-items-center">
        <h1 class="main_title">Авторизация</h1>
        <p class="fs-5 mt-3 text-center">Здесь вы можете авторизоваться на сайте</p>
        <form action="<?php echo e(route('auth.login')); ?>" method="POST" class="w-25">
            <?php echo csrf_field(); ?>
            <input type="text" name="login" class="form-control  mt-3" placeholder="Введите логин" value="<?php echo e(old('login')); ?>">
            <input type="password" name="password" class="form-control mt-3" placeholder="Введите пароль" >
            <?php echo $__env->make('blocks.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <button type="submit" class="mt-3 btn btn-danger">Войти</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/resources/views/auth/index.blade.php ENDPATH**/ ?>