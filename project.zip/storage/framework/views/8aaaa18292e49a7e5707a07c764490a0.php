<?php $__env->startSection('title'); ?> Личный кабинет <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex flex-column align-items-center">
        <h1 class="main_title"><?php echo e(\Illuminate\Support\Facades\Auth::user()->login); ?></h1>
        <a href="<?php echo e(route('auth.logout')); ?>" class="btn btn-danger">Выйти</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/resources/views/auth/user.blade.php ENDPATH**/ ?>