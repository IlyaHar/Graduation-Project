<?php $__env->startSection('title'); ?> Главная страница <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex flex-column align-items-center">
        <h1 class="main_title">Авторизация</h1>
        <p class="fs-5 mt-3 text-center">Здесь вы можете авторизоваться на сайте</p>
        <form action="" method="POST" class="w-25">
            <input type="text" name="login" class="form-control  mt-3" placeholder="Введите логин">
            <input type="password" name="password" class="form-control mt-3" placeholder="Введите пароль">
            <button type="submit" class="mt-4 btn btn-danger">Войти</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/resources/views/index.blade.php ENDPATH**/ ?>
