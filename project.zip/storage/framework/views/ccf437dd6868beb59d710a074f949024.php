<div class="container">
    <header class="d-flex flex-wrap justify-content-center align-items-center py-3 mb-4 border-bottom">
        <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-body-emphasis text-decoration-none">
            <img src="/storage/images/cat.png" alt="logo">
            <span class="fs-4 mx-3">Уберем все <br>лишнее из ссылки!</span>
        </a>
        <ul class="nav nav-pills fs-6">
            <li class="nav-item"><a href="<?php echo e(route('home')); ?>" class="nav-link text-secondary">Главная</a></li>
            <li class="nav-item"><a href="<?php echo e(route('about')); ?>" class="nav-link text-secondary">Про нас</a></li>
            <li class="nav-item"><a href="<?php echo e(route('contacts.index')); ?>" class="nav-link text-secondary">Контакты</a></li>
            <?php if(auth()->guard()->guest()): ?>
            <li class="nav-item"><a href="<?php echo e(route('auth.index')); ?>" class="nav-link text-secondary">Войти</a></li>
            <?php endif; ?>
            <?php if(auth()->guard()->check()): ?>
                <li class="nav-item"><a href="<?php echo e(route('auth.user')); ?>" class="nav-link text-secondary">Личный кабинет</a></li>
            <?php endif; ?>
        </ul>
    </header>
</div>
<?php /**PATH /opt/lampp/htdocs/resources/views/blocks/header.blade.php ENDPATH**/ ?>