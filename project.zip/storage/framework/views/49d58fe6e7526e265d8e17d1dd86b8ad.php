<?php $__env->startSection('title'); ?> Про нас <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex flex-column align-items-center">
        <h1 class="main_title">Про нас</h1>
        <p class="fs-5 mt-3 text-center">Здесь вы можете прочитать информацию про нас</p>
        <p class="fs-5 mt-3 text-capitalize ">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer non lobortis orci. Pellentesque a risus feugiat urna mollis pellentesque in molestie sapien.
            Phasellus orci neque, ultricies at rutrum vel, commodo sed elit. Sed commodo auctor quam eu efficitur. Duis eget faucibus metus.
            Maecenas quis magna purus. Cras in feugiat tellus.
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed a augue in quam dapibus viverra eu eu odio. Maecenas sed felis orci.
            Cras fermentum porta ante. Interdum et malesuada fames ac ante ipsum primis in faucibus. Praesent ipsum nulla, ornare eget ligula eu,
            malesuada maximus magna. Nam posuere eget lectus sit amet pharetra. Maecenas vel lacus quis tellus efficitur dapibus sed nec orci.
            Nullam eget viverra lorem, at placerat ligula. Curabitur euismod orci ipsum. Quisque suscipit vehicula ligula laoreet gravida.
            Integer pharetra eleifend commodo. Duis fringilla mattis libero, ut aliquam tortor rhoncus pulvinar. Donec volutpat ornare ultricies.
            Phasellus sodales facilisis porttitor. Nam sit amet tellus nisi. Nunc et est sapien. Etiam ut ipsum tortor. Mauris pulvinar volutpat libero, sed condimentum ante placerat et.
            In tempor orci leo, eu tempor mi sagittis quis. Vestibulum id lectus a arcu ultrices scelerisque et vitae erat. Vivamus imperdiet et sapien sed accumsan. Aliquam eu nisl non eros fringilla maximus in vitae ex. Suspendisse sollicitudin, sem eget sodales hendrerit, massa ante consequat purus, nec euismod leo felis vel nulla. Nunc leo arcu, sodales et odio a, laoreet tincidunt eros. Praesent quis lectus vel quam rhoncus finibus et ut risus.
        </p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/resources/views/about.blade.php ENDPATH**/ ?>