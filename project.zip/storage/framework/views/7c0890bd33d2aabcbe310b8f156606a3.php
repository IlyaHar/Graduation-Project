<?php if($errors->any()): ?>
    <div>
        <strong><p class="text-danger mt-4"><?php echo e($errors->first()); ?></p></strong>
    </div>
<?php endif; ?>

<?php if(session('success')): ?>
    <div>
        <strong><p class="text-success mt-4"><?php echo e(session('success')); ?></p></strong>
    </div>
<?php endif; ?>
<?php /**PATH /opt/lampp/htdocs/resources/views/blocks/messages.blade.php ENDPATH**/ ?>