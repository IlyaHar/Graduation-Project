<?php $__env->startSection('title'); ?> Главная страница <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex flex-column align-items-center">
        <h1 class="main_title">Сокра.тим</h1>
        <?php if(auth()->guard()->guest()): ?>
        <p class="fs-5 mt-3 text-center">Вам нужно сделать ссылку? Прежде чем это сделать<br> зарегистрируйтесь на сайте</p>
        <form action="<?php echo e(route('auth.register')); ?>" method="POST" class="w-25" novalidate>
            <?php echo csrf_field(); ?>
            <input type="email" name="email" class="form-control mt-4" placeholder="Введите email" value="<?php echo e(old('email')); ?>">
            <input type="text" name="login" class="form-control  mt-3" placeholder="Введите логин"  value="<?php echo e(old('login')); ?>">
            <input type="password" name="password" class="form-control mt-3" placeholder="Введите пароль"  value="<?php echo e(old('password')); ?>">
            <?php echo $__env->make('blocks.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <button type="submit" class="mt-3 btn btn-danger">Зарегистрироваться</button>
        </form>
        <p class="mt-4">Есть аккаунт? Тогда вы можете <a href="<?php echo e(route('auth.index')); ?>" class="text-primary">авторизоваться</a></p>
        <?php endif; ?>
        <?php if(auth()->guard()->check()): ?>
            <p class="fs-5 mt-3 text-center">Вам нужно сократить ссылку? Сейчас мы это сделаем</p>
            <form action="<?php echo e(route('link.store')); ?>" method="POST" class="w-25" novalidate>
                <?php echo csrf_field(); ?>
                <input type="text" name="link" class="form-control mt-4" placeholder="Длинная ссылка" value="<?php echo e(old('link')); ?>">
                <input type="text" name="title" class="form-control  mt-3" placeholder="Короткое название"  value="<?php echo e(old('title')); ?>">
                <?php echo $__env->make('blocks.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <button type="submit" class="mt-3 btn btn-danger">Уменьшить</button>
            </form>

            <?php ($links = \Illuminate\Support\Facades\Auth::user()->links); ?>

                <div class="mt-4">
                    <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="link_card bg-secondary-subtle mt-3">
                            <p>Длинная: <?php echo e($link->link); ?></p>
                            <p>Короткая: <a target="_blank" href="<?php echo e($link->link); ?>"><?php echo e($link->title); ?></a></p>
                            <form action="<?php echo e(route('link.delete', $link->id)); ?>" method="POST">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-danger">Удалить</button>
                            </form>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/resources/views/home.blade.php ENDPATH**/ ?>