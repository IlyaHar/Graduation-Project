<?php $__env->startSection('title'); ?> Обратная связь <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex flex-column align-items-center">
        <h1 class="main_title">Обратная связь</h1>
        <p class="fs-5 mt-3 text-center">Напишите нам, если у вас есть вопросы</p>
        <form action="<?php echo e(route('contacts.store')); ?>" method="POST" class="w-25" novalidate>
            <?php echo csrf_field(); ?>
            <input type="text" name="name" class="form-control  mt-4" placeholder="Введите имя" value="<?php echo e(old('name', \Illuminate\Support\Facades\Auth::user()->login ?? '')); ?>">
            <input type="email" name="email" class="form-control mt-3" placeholder="Введите email" value="<?php echo e(old('email', \Illuminate\Support\Facades\Auth::user()->email ?? '')); ?>" >
            <input type="number" name="age" class="form-control mt-3" placeholder="Введите возвраст" value="<?php echo e(old('age')); ?>">
            <textarea name="message" class="form-control mt-3" cols="30" rows="10" placeholder="Введите само сообщение" ><?php echo e(old('message')); ?></textarea>
            <?php echo $__env->make('blocks.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <button type="submit" class="mt-3 btn btn-danger">Отправить</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/resources/views/contacts.blade.php ENDPATH**/ ?>